$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 200) {
        $(".fixed-top").addClass("topnav");
    } else {
        $(".fixed-top").removeClass("topnav");
    }
});


$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 200) {
        $("#topbar").addClass("hides");
    } else {
        $("topbar").removeClass("hides");
    }
});

$(document).ready(function(){
    $(".navbar-toggler-icon").click(function(){
      $("#navbarSupportedContent").slideToggle();
    });
  });